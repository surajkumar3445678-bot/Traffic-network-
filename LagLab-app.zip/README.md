# LagLab

Android app (no root) that slows your own network for a few seconds, for testing.
A floating button starts the lag; after N seconds it switches off by itself.

## APK banane ka tarika (GitHub)
1. GitHub par naya repo banao.
2. Is zip ki saari files upload karo (`.github` folder ke saath).
3. Repo me Actions tab -> "Build APK" -> Run workflow.
4. Build ke baad us run ke Artifacts me `LagLab-debug-apk` download karo.

## Use
- START dabao, permissions do (Display over other apps + VPN).
- Floating button par tap = lag shuru, N sec baad apne aap band. Lag ke beech tap = turant band.
- Button ko pakad kar kahin bhi khiskao.

Lag amount fixed hai (300 ms har direction me), `LagState.LAG_MS` me badal sakte ho.
