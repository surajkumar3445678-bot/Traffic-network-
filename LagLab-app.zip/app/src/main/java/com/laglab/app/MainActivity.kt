package com.laglab.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat

class MainActivity : Activity() {

    private val cBg = Color.parseColor("#0C1015")
    private val cSurface = Color.parseColor("#151A21")
    private val cBorder = Color.parseColor("#232A34")
    private val cChip = Color.parseColor("#202732")
    private val cText = Color.parseColor("#E6EAF0")
    private val cMuted = Color.parseColor("#8E99A8")
    private val cMint = Color.parseColor("#2EE6A6")
    private val cDark = Color.parseColor("#08110D")
    private val cOrange = Color.parseColor("#FF7A45")

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var summarySub: TextView
    private lateinit var startBtn: Button
    private lateinit var secValue: TextView
    private lateinit var chipsRow: LinearLayout
    private lateinit var sizeLabel: TextView
    private lateinit var sizeSeek: SeekBar
    private lateinit var previewDot: TextView
    private lateinit var targetName: TextView

    private val secChoices = intArrayOf(1, 2, 3, 5, 10)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = cBg
        window.navigationBarColor = cBg
        setContentView(buildUi())
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        refreshUi()
    }

    override fun onResume() {
        super.onResume()
        refreshUi()
    }

    // ------------------------------------------------------------ UI building

    private fun dp(v: Int) = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun shape(color: Int, radiusDp: Int, stroke: Int? = null): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radiusDp).toFloat()
        if (stroke != null) g.setStroke(dp(1), stroke)
        return g
    }

    private fun text(t: String, sizeSp: Float, color: Int, bold: Boolean = false): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = sizeSp
        v.setTextColor(color)
        if (bold) v.typeface = Typeface.DEFAULT_BOLD
        return v
    }

    private fun card(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.background = shape(cSurface, 20, cBorder)
        l.setPadding(dp(16), dp(14), dp(16), dp(14))
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.topMargin = dp(12)
        l.layoutParams = lp
        return l
    }

    private fun smallLabel(t: String) = text(t, 11f, cMuted)

    private fun flatButton(label: String, fill: Int, textColor: Int, bold: Boolean = false): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.setTextColor(textColor)
        b.background = shape(fill, 10)
        b.stateListAnimator = null
        b.minHeight = 0
        b.minimumHeight = 0
        b.minWidth = 0
        b.minimumWidth = 0
        b.setPadding(dp(14), 0, dp(14), 0)
        if (bold) b.typeface = Typeface.DEFAULT_BOLD
        return b
    }

    private fun buildUi(): ScrollView {
        val root = ScrollView(this)
        root.setBackgroundColor(cBg)
        root.isFillViewport = true
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(18), dp(44), dp(18), dp(28))
        root.addView(col, ViewGroup.LayoutParams(MATCH, WRAP))

        // header
        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        val logo = text("⚡", 20f, cDark, true)
        logo.gravity = Gravity.CENTER
        logo.background = shape(cMint, 12)
        head.addView(logo, LinearLayout.LayoutParams(dp(40), dp(40)))
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        titles.addView(text("LagLab", 22f, cText, true))
        titles.addView(text("Network slowdown for testing", 12f, cMuted))
        val tl = LinearLayout.LayoutParams(0, WRAP, 1f)
        tl.marginStart = dp(12)
        head.addView(titles, tl)
        col.addView(head)

        // summary
        val sum = card()
        sum.addView(text("Tap to lag", 20f, cText, true))
        summarySub = text("", 13f, cMuted)
        sum.addView(summarySub)
        col.addView(sum)

        // start / stop
        startBtn = Button(this)
        startBtn.isAllCaps = false
        startBtn.textSize = 17f
        startBtn.typeface = Typeface.DEFAULT_BOLD
        startBtn.stateListAnimator = null
        startBtn.setOnClickListener { onStartStop() }
        val sl = LinearLayout.LayoutParams(MATCH, dp(60))
        sl.topMargin = dp(12)
        col.addView(startBtn, sl)

        // duration
        val dur = card()
        dur.addView(smallLabel("LAG DURATION"))
        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER_VERTICAL
        val minus = flatButton("−", cChip, cText)
        minus.textSize = 22f
        minus.setOnClickListener { changeSeconds(-1) }
        val plus = flatButton("+", cChip, cText)
        plus.textSize = 22f
        plus.setOnClickListener { changeSeconds(1) }
        secValue = text("", 32f, cText, true)
        secValue.gravity = Gravity.CENTER
        row.addView(minus, LinearLayout.LayoutParams(dp(48), dp(48)))
        row.addView(secValue, LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(plus, LinearLayout.LayoutParams(dp(48), dp(48)))
        dur.addView(row)
        chipsRow = LinearLayout(this)
        val cl = LinearLayout.LayoutParams(MATCH, WRAP)
        cl.topMargin = dp(10)
        dur.addView(chipsRow, cl)
        col.addView(dur)

        // size
        val size = card()
        val sizeHead = LinearLayout(this)
        sizeHead.addView(smallLabel("BUTTON SIZE"), LinearLayout.LayoutParams(0, WRAP, 1f))
        sizeLabel = text("", 13f, cText, true)
        sizeHead.addView(sizeLabel)
        size.addView(sizeHead)
        val sizeRow = LinearLayout(this)
        sizeRow.gravity = Gravity.CENTER_VERTICAL
        sizeSeek = SeekBar(this)
        sizeSeek.max = 100
        sizeSeek.progressTintList = ColorStateList.valueOf(cMint)
        sizeSeek.thumbTintList = ColorStateList.valueOf(Color.WHITE)
        sizeSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                Prefs.setSizeDp(this@MainActivity, 28 + (p * 0.44f).toInt())
                refreshUi()
                FloatingService.instance?.applySettings()
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        sizeRow.addView(sizeSeek, LinearLayout.LayoutParams(0, WRAP, 1f))
        val box = LinearLayout(this)
        box.gravity = Gravity.CENTER
        box.background = shape(cBg, 14, cBorder)
        previewDot = text("", 11f, cDark, true)
        previewDot.gravity = Gravity.CENTER
        box.addView(previewDot)
        val bl = LinearLayout.LayoutParams(dp(80), dp(80))
        bl.marginStart = dp(12)
        sizeRow.addView(box, bl)
        size.addView(sizeRow)
        col.addView(size)

        // target app
        val target = card()
        val tRow = LinearLayout(this)
        tRow.gravity = Gravity.CENTER_VERTICAL
        val tCol = LinearLayout(this)
        tCol.orientation = LinearLayout.VERTICAL
        tCol.addView(smallLabel("SLOW ONLY THIS APP"))
        targetName = text("", 15f, cText, true)
        tCol.addView(targetName)
        tRow.addView(tCol, LinearLayout.LayoutParams(0, WRAP, 1f))
        val change = flatButton("Change", cChip, cText)
        change.setOnClickListener { pickApp() }
        tRow.addView(change, LinearLayout.LayoutParams(WRAP, dp(36)))
        target.addView(tRow)
        col.addView(target)

        val hint = text("First start asks for 'Display over other apps' and VPN permission. Changing the app needs STOP then START.", 11f, cMuted)
        val hl = LinearLayout.LayoutParams(MATCH, WRAP)
        hl.topMargin = dp(14)
        col.addView(hint, hl)
        return root
    }

    private fun changeSeconds(delta: Int) {
        val v = (Prefs.seconds(this) + delta).coerceIn(1, 60)
        Prefs.setSeconds(this, v)
        refreshUi()
        FloatingService.instance?.applySettings()
    }

    private fun refreshUi() {
        val sec = Prefs.seconds(this)
        val tPkg = Prefs.target(this)
        secValue.text = "$sec sec"
        summarySub.text = "$sec sec lag · " + (if (tPkg.isEmpty()) "all apps" else "only " + Prefs.targetLabel(this))
        targetName.text = Prefs.targetLabel(this)

        if (LagState.running) {
            startBtn.text = "■  STOP"
            startBtn.setTextColor(cText)
            startBtn.background = shape(cOrange, 16)
        } else {
            startBtn.text = "▶  START"
            startBtn.setTextColor(cDark)
            startBtn.background = shape(cMint, 16)
        }

        chipsRow.removeAllViews()
        for (c in secChoices) {
            val b = flatButton("${c}s", if (c == sec) cMint else cChip, if (c == sec) cDark else cText, c == sec)
            b.setOnClickListener {
                Prefs.setSeconds(this, c)
                refreshUi()
                FloatingService.instance?.applySettings()
            }
            val lp = LinearLayout.LayoutParams(0, dp(36), 1f)
            lp.marginEnd = dp(6)
            chipsRow.addView(b, lp)
        }

        val sizeDp = Prefs.sizeDp(this)
        sizeSeek.progress = ((sizeDp - 28) / 0.44f).toInt().coerceIn(0, 100)
        sizeLabel.text = if (sizeDp < 40) "Small" else if (sizeDp < 56) "Medium" else "Large"
        val lp = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        previewDot.layoutParams = lp
        previewDot.background = shape(cMint, 100)
        previewDot.text = "${sec}s"
    }

    // ------------------------------------------------------------ actions

    private fun onStartStop() {
        if (LagState.running) {
            stopService(Intent(this, FloatingService::class.java))
            stopService(Intent(this, LagVpnService::class.java))
            LagState.running = false
            refreshUi()
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow 'Display over other apps', then press START again", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val prep = VpnService.prepare(this)
        if (prep != null) {
            startActivityForResult(prep, 100)
        } else {
            startAll()
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK) startAll()
    }

    private fun startAll() {
        startService(Intent(this, LagVpnService::class.java))
        ContextCompat.startForegroundService(this, Intent(this, FloatingService::class.java))
        LagState.running = true
        refreshUi()
    }

    private fun pickApp() {
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(q, 0)
            .map { Pair(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .filter { it.second != packageName }
            .distinctBy { it.second }
            .sortedBy { it.first.lowercase() }
        val names = (listOf("All apps") + apps.map { it.first }).toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Slow only this app")
            .setItems(names) { _, which ->
                if (which == 0) {
                    Prefs.setTarget(this, "", "All apps")
                } else {
                    val a = apps[which - 1]
                    Prefs.setTarget(this, a.second, a.first)
                }
                refreshUi()
                if (LagState.running) {
                    Toast.makeText(this, "Press STOP, then START to apply", Toast.LENGTH_SHORT).show()
                }
            }
            .show()
    }
}
