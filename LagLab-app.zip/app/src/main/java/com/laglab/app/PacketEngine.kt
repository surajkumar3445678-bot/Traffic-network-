package com.laglab.app

import android.net.VpnService
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.ByteBuffer
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.ScheduledThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock
import kotlin.random.Random

private const val F_FIN = 1
private const val F_SYN = 2
private const val F_RST = 4
private const val F_PSH = 8
private const val F_ACK = 16
private const val MSS = 1360
private val EMPTY = ByteArray(0)
private val FIN_MARK = ByteArray(0)

/**
 * Minimal user-space IPv4 forwarder (TCP + UDP) for a VpnService tunnel.
 * Every packet going in or out can be held back for LagState.LAG_MS while lag is active.
 * IPv6 and ICMP are not forwarded.
 */
class PacketEngine(private val vpn: VpnService, private val tun: ParcelFileDescriptor) {

    private class Timed(val readyAt: Long, val data: ByteArray)

    private val input = FileInputStream(tun.fileDescriptor)
    private val output = FileOutputStream(tun.fileDescriptor)

    @Volatile private var running = true
    private val ingress = LinkedBlockingQueue<Timed>()
    private val egress = LinkedBlockingQueue<Timed>()
    private var lastIn = 0L
    private var lastOut = 0L
    private val outLock = Any()
    private val ipId = AtomicInteger(1)
    private val tcpConns = ConcurrentHashMap<String, TcpConn>()
    private val udpSessions = ConcurrentHashMap<String, UdpSession>()
    private val timer = ScheduledThreadPoolExecutor(1)

    // ---------------------------------------------------------------- lifecycle

    fun start() {
        runBg("tun-read") { readLoop() }
        runBg("tun-in") { ingressLoop() }
        runBg("tun-out") { writeLoop() }
    }

    fun stop() {
        running = false
        try {
            tun.close()
        } catch (e: Exception) {
        }
        for (c in tcpConns.values) closeConn(c)
        for (s in udpSessions.values) s.close()
        ingress.offer(Timed(0, EMPTY))
        egress.offer(Timed(0, EMPTY))
        timer.shutdownNow()
    }

    private fun runBg(name: String, block: () -> Unit): Thread {
        val t = Thread({
            try {
                block()
            } catch (e: Exception) {
            }
        }, name)
        t.isDaemon = true
        t.start()
        return t
    }

    // ---------------------------------------------------------------- delay pipeline

    private fun delayNow(): Long = if (LagState.active) LagState.LAG_MS else 0L

    private fun sleepUntil(at: Long) {
        val w = at - System.currentTimeMillis()
        if (w > 0) {
            try {
                Thread.sleep(w)
            } catch (e: InterruptedException) {
            }
        }
    }

    private fun readLoop() {
        val buf = ByteArray(32767)
        while (running) {
            val n = try {
                input.read(buf)
            } catch (e: Exception) {
                break
            }
            if (n < 0) break
            if (n == 0) continue
            val data = buf.copyOf(n)
            val ready = maxOf(lastIn, System.currentTimeMillis() + delayNow())
            lastIn = ready
            ingress.put(Timed(ready, data))
        }
    }

    private fun ingressLoop() {
        while (running) {
            val t = try {
                ingress.take()
            } catch (e: InterruptedException) {
                break
            }
            if (!running) break
            sleepUntil(t.readyAt)
            try {
                handlePacket(t.data)
            } catch (e: Exception) {
            }
        }
    }

    private fun writeLoop() {
        while (running) {
            val t = try {
                egress.take()
            } catch (e: InterruptedException) {
                break
            }
            if (!running) break
            sleepUntil(t.readyAt)
            try {
                output.write(t.data)
            } catch (e: Exception) {
                if (!running) break
            }
        }
    }

    private fun sendToTun(pkt: ByteArray) {
        synchronized(outLock) {
            val ready = maxOf(lastOut, System.currentTimeMillis() + delayNow())
            lastOut = ready
            egress.put(Timed(ready, pkt))
        }
    }

    // ---------------------------------------------------------------- packet dispatch

    private fun handlePacket(p: ByteArray) {
        if (p.size < 20) return
        val ver = (p[0].toInt() ushr 4) and 0xF
        if (ver != 4) return
        val ihl = (p[0].toInt() and 0xF) * 4
        val total = u16(p, 2)
        val len = minOf(total, p.size)
        if (len < ihl) return
        val proto = p[9].toInt() and 0xFF
        val srcIp = readInt(p, 12)
        val dstIp = readInt(p, 16)
        when (proto) {
            6 -> handleTcp(p, ihl, len, srcIp, dstIp)
            17 -> handleUdp(p, ihl, len, srcIp, dstIp)
        }
    }

    // ---------------------------------------------------------------- UDP

    private fun handleUdp(p: ByteArray, ihl: Int, len: Int, srcIp: Int, dstIp: Int) {
        if (len - ihl < 8) return
        val sp = u16(p, ihl)
        val dp = u16(p, ihl + 2)
        val payload = p.copyOfRange(ihl + 8, len)
        val key = "$srcIp:$sp>$dstIp:$dp"
        var s = udpSessions[key]
        if (s == null) {
            val ns = try {
                UdpSession(key, srcIp, sp, dstIp, dp)
            } catch (e: Exception) {
                return
            }
            udpSessions[key] = ns
            ns.startReader()
            s = ns
        }
        s.send(payload)
    }

    private inner class UdpSession(
        val key: String, val srcIp: Int, val srcPort: Int, val dstIp: Int, val dstPort: Int
    ) {
        private val sock = DatagramSocket()

        init {
            vpn.protect(sock)
            sock.connect(InetAddress.getByAddress(ipBytes(dstIp)), dstPort)
            sock.soTimeout = if (dstPort == 53) 5000 else 60000
        }

        fun send(payload: ByteArray) {
            try {
                sock.send(DatagramPacket(payload, payload.size))
            } catch (e: Exception) {
                close()
            }
        }

        fun startReader() {
            runBg("udp") {
                val buf = ByteArray(2048)
                try {
                    while (running) {
                        val dp = DatagramPacket(buf, buf.size)
                        sock.receive(dp)
                        if (dp.length > 1472) continue
                        val data = buf.copyOf(dp.length)
                        sendToTun(buildUdp(dstIp, srcIp, dstPort, srcPort, data))
                    }
                } catch (e: Exception) {
                } finally {
                    close()
                }
            }
        }

        fun close() {
            udpSessions.remove(key)
            try {
                sock.close()
            } catch (e: Exception) {
            }
        }
    }

    // ---------------------------------------------------------------- TCP

    private inner class TcpConn(
        val key: String, val srcIp: Int, val srcPort: Int, val dstIp: Int, val dstPort: Int
    ) {
        val isn: Int = Random.nextInt()
        var socket: Socket? = null
        var clientNext = 0
        var serverSeq = 0
        var clientAcked = 0
        var clientWin = 65535
        var connected = false
        var finSent = false
        var clientFin = false
        @Volatile var closed = false
        val toServer = LinkedBlockingQueue<ByteArray>()
        val threads = CopyOnWriteArrayList<Thread>()
        val lock = ReentrantLock()
        val cond = lock.newCondition()
    }

    private fun handleTcp(p: ByteArray, ihl: Int, len: Int, srcIp: Int, dstIp: Int) {
        if (len - ihl < 20) return
        val sp = u16(p, ihl)
        val dp = u16(p, ihl + 2)
        val seq = readInt(p, ihl + 4)
        val ack = readInt(p, ihl + 8)
        val dataOff = ((p[ihl + 12].toInt() and 0xF0) ushr 4) * 4
        val flags = p[ihl + 13].toInt() and 0x3F
        val win = u16(p, ihl + 14)
        if (dataOff < 20 || len < ihl + dataOff) return
        val payloadStart = ihl + dataOff
        val payloadLen = len - payloadStart
        val key = "$srcIp:$sp>$dstIp:$dp"
        val existing = tcpConns[key]

        if (flags and F_RST != 0) {
            if (existing != null) closeConn(existing)
            return
        }

        if (flags and F_SYN != 0 && flags and F_ACK == 0) {
            if (existing != null) return // retransmitted SYN
            val nc = TcpConn(key, srcIp, sp, dstIp, dp)
            nc.clientNext = seq + 1
            nc.clientWin = win
            tcpConns[key] = nc
            runBg("tcp-connect") { doConnect(nc) }
            return
        }

        if (existing == null) {
            if (payloadLen > 0 || flags and F_FIN != 0) {
                val rstAck = seq + payloadLen + (if (flags and F_FIN != 0) 1 else 0)
                sendToTun(buildTcp(dstIp, srcIp, dp, sp, ack, rstAck, F_RST or F_ACK, 0, EMPTY))
            }
            return
        }
        val c: TcpConn = existing
        if (!c.connected) return

        c.lock.withLock {
            if (flags and F_ACK != 0) {
                if (ack - c.clientAcked > 0) c.clientAcked = ack
                c.clientWin = win
                c.cond.signalAll()
            }
            if (payloadLen > 0) {
                val d = c.clientNext - seq
                if (d >= 0 && d < payloadLen) {
                    val chunk = p.copyOfRange(payloadStart + d, payloadStart + payloadLen)
                    c.toServer.put(chunk)
                    c.clientNext += chunk.size
                }
                sendAck(c)
            }
            if (flags and F_FIN != 0) {
                if (!c.clientFin && seq + payloadLen == c.clientNext) {
                    c.clientFin = true
                    c.clientNext += 1
                    c.toServer.put(FIN_MARK)
                }
                sendAck(c)
            }
        }
        checkFinished(c)
    }

    private fun doConnect(c: TcpConn) {
        val s = Socket()
        try {
            vpn.protect(s)
            s.tcpNoDelay = true
            s.connect(InetSocketAddress(InetAddress.getByAddress(ipBytes(c.dstIp)), c.dstPort), 8000)
        } catch (e: Exception) {
            try {
                s.close()
            } catch (e2: Exception) {
            }
            refuse(c)
            return
        }
        if (c.closed) {
            s.close()
            return
        }
        c.socket = s
        c.lock.withLock {
            c.serverSeq = c.isn + 1
            c.clientAcked = c.isn + 1
            c.connected = true
        }
        sendToTun(buildTcp(c.dstIp, c.srcIp, c.dstPort, c.srcPort, c.isn, c.clientNext, F_SYN or F_ACK, 65535, EMPTY, MSS))
        c.threads.add(runBg("tcp-w") { writerLoop(c, s) })
        c.threads.add(runBg("tcp-r") { readerLoop(c, s) })
    }

    private fun writerLoop(c: TcpConn, s: Socket) {
        try {
            val out = s.getOutputStream()
            while (!c.closed) {
                val d = c.toServer.take()
                if (d === FIN_MARK) {
                    s.shutdownOutput()
                } else {
                    out.write(d)
                    out.flush()
                }
            }
        } catch (e: InterruptedException) {
        } catch (e: Exception) {
            if (!c.closed) failConn(c)
        }
    }

    private fun readerLoop(c: TcpConn, s: Socket) {
        val buf = ByteArray(MSS)
        try {
            val ins = s.getInputStream()
            while (!c.closed) {
                var avail = 0
                c.lock.withLock {
                    while (!c.closed) {
                        val inflight = c.serverSeq - c.clientAcked
                        avail = c.clientWin - inflight
                        if (avail > 0) break
                        c.cond.await(200, TimeUnit.MILLISECONDS)
                    }
                }
                if (c.closed) break
                val n = ins.read(buf, 0, minOf(MSS, avail))
                if (n < 0) {
                    sendFin(c)
                    break
                }
                if (n == 0) continue
                c.lock.withLock {
                    val data = buf.copyOf(n)
                    val pkt = buildTcp(c.dstIp, c.srcIp, c.dstPort, c.srcPort, c.serverSeq, c.clientNext, F_PSH or F_ACK, 65535, data)
                    c.serverSeq += n
                    sendToTun(pkt)
                }
            }
        } catch (e: Exception) {
            if (!c.closed) failConn(c)
        }
    }

    private fun sendAck(c: TcpConn) {
        c.lock.withLock {
            sendToTun(buildTcp(c.dstIp, c.srcIp, c.dstPort, c.srcPort, c.serverSeq, c.clientNext, F_ACK, 65535, EMPTY))
        }
    }

    private fun sendFin(c: TcpConn) {
        c.lock.withLock {
            if (!c.finSent) {
                sendToTun(buildTcp(c.dstIp, c.srcIp, c.dstPort, c.srcPort, c.serverSeq, c.clientNext, F_FIN or F_ACK, 65535, EMPTY))
                c.serverSeq += 1
                c.finSent = true
            }
        }
        checkFinished(c)
    }

    private fun checkFinished(c: TcpConn) {
        val done = c.lock.withLock { c.finSent && c.clientFin }
        if (done && !c.closed) {
            try {
                timer.schedule(Runnable { closeConn(c) }, 3, TimeUnit.SECONDS)
            } catch (e: Exception) {
            }
        }
    }

    private fun refuse(c: TcpConn) {
        sendToTun(buildTcp(c.dstIp, c.srcIp, c.dstPort, c.srcPort, 0, c.clientNext, F_RST or F_ACK, 0, EMPTY))
        closeConn(c)
    }

    private fun failConn(c: TcpConn) {
        val seq = c.lock.withLock { c.serverSeq }
        sendToTun(buildTcp(c.dstIp, c.srcIp, c.dstPort, c.srcPort, seq, c.clientNext, F_RST or F_ACK, 0, EMPTY))
        closeConn(c)
    }

    private fun closeConn(c: TcpConn) {
        c.closed = true
        tcpConns.remove(c.key)
        try {
            c.socket?.close()
        } catch (e: Exception) {
        }
        for (t in c.threads) t.interrupt()
        c.lock.withLock { c.cond.signalAll() }
    }

    // ---------------------------------------------------------------- packet building

    private fun buildTcp(
        srcIp: Int, dstIp: Int, srcPort: Int, dstPort: Int,
        seq: Int, ack: Int, flags: Int, window: Int, payload: ByteArray, mss: Int = 0
    ): ByteArray {
        val tcpHdr = 20 + (if (mss > 0) 4 else 0)
        val tcpLen = tcpHdr + payload.size
        val total = 20 + tcpLen
        val b = ByteBuffer.allocate(total)
        b.put(0x45.toByte())
        b.put(0.toByte())
        b.putShort(total.toShort())
        b.putShort(ipId.incrementAndGet().toShort())
        b.putShort(0x4000.toShort())
        b.put(64.toByte())
        b.put(6.toByte())
        b.putShort(0.toShort())
        b.putInt(srcIp)
        b.putInt(dstIp)
        b.putShort(srcPort.toShort())
        b.putShort(dstPort.toShort())
        b.putInt(seq)
        b.putInt(ack)
        b.put(((tcpHdr / 4) shl 4).toByte())
        b.put(flags.toByte())
        b.putShort(window.toShort())
        b.putShort(0.toShort())
        b.putShort(0.toShort())
        if (mss > 0) {
            b.put(2.toByte())
            b.put(4.toByte())
            b.putShort(mss.toShort())
        }
        b.put(payload)
        val a = b.array()
        val ipc = checksum(a, 0, 20, 0L)
        a[10] = (ipc shr 8).toByte()
        a[11] = ipc.toByte()
        val tc = checksum(a, 20, tcpLen, pseudoSum(srcIp, dstIp, 6, tcpLen))
        a[36] = (tc shr 8).toByte()
        a[37] = tc.toByte()
        return a
    }

    private fun buildUdp(srcIp: Int, dstIp: Int, srcPort: Int, dstPort: Int, payload: ByteArray): ByteArray {
        val udpLen = 8 + payload.size
        val total = 20 + udpLen
        val b = ByteBuffer.allocate(total)
        b.put(0x45.toByte())
        b.put(0.toByte())
        b.putShort(total.toShort())
        b.putShort(ipId.incrementAndGet().toShort())
        b.putShort(0x4000.toShort())
        b.put(64.toByte())
        b.put(17.toByte())
        b.putShort(0.toShort())
        b.putInt(srcIp)
        b.putInt(dstIp)
        b.putShort(srcPort.toShort())
        b.putShort(dstPort.toShort())
        b.putShort(udpLen.toShort())
        b.putShort(0.toShort())
        b.put(payload)
        val a = b.array()
        val ipc = checksum(a, 0, 20, 0L)
        a[10] = (ipc shr 8).toByte()
        a[11] = ipc.toByte()
        var uc = checksum(a, 20, udpLen, pseudoSum(srcIp, dstIp, 17, udpLen))
        if (uc == 0) uc = 0xFFFF
        a[26] = (uc shr 8).toByte()
        a[27] = uc.toByte()
        return a
    }

    private fun pseudoSum(srcIp: Int, dstIp: Int, proto: Int, len: Int): Long {
        return (((srcIp ushr 16) and 0xFFFF) + (srcIp and 0xFFFF) +
            ((dstIp ushr 16) and 0xFFFF) + (dstIp and 0xFFFF) + proto + len).toLong()
    }

    private fun checksum(a: ByteArray, off: Int, len: Int, init: Long): Int {
        var sum = init
        var i = off
        val end = off + len
        while (i + 1 < end) {
            sum += (((a[i].toInt() and 0xFF) shl 8) or (a[i + 1].toInt() and 0xFF)).toLong()
            i += 2
        }
        if (i < end) sum += ((a[i].toInt() and 0xFF) shl 8).toLong()
        while ((sum shr 16) != 0L) sum = (sum and 0xFFFF) + (sum shr 16)
        return (sum.inv() and 0xFFFF).toInt()
    }

    private fun u16(a: ByteArray, o: Int): Int = ((a[o].toInt() and 0xFF) shl 8) or (a[o + 1].toInt() and 0xFF)

    private fun readInt(a: ByteArray, o: Int): Int =
        ((a[o].toInt() and 0xFF) shl 24) or ((a[o + 1].toInt() and 0xFF) shl 16) or
            ((a[o + 2].toInt() and 0xFF) shl 8) or (a[o + 3].toInt() and 0xFF)

    private fun ipBytes(i: Int): ByteArray =
        byteArrayOf((i ushr 24).toByte(), (i ushr 16).toByte(), (i ushr 8).toByte(), i.toByte())
}
