package com.laglab.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.TextView
import kotlin.math.abs

class FloatingService : Service() {

    companion object {
        @Volatile var instance: FloatingService? = null
    }

    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var view: TextView? = null
    private val handler = Handler(Looper.getMainLooper())
    private var remaining = 0

    private var downX = 0f
    private var downY = 0f
    private var startX = 0
    private var startY = 0
    private var moved = false

    private val tick = object : Runnable {
        override fun run() {
            remaining--
            if (remaining <= 0) {
                stopLag()
            } else {
                render()
                handler.postDelayed(this, 1000)
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        startForegroundNotification()
        addButton()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    private fun px(dp: Int) = (dp * resources.displayMetrics.density + 0.5f).toInt()

    private fun startForegroundNotification() {
        val channelId = "laglab"
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(channelId, "LagLab", NotificationManager.IMPORTANCE_LOW)
            )
        }
        @Suppress("DEPRECATION")
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, channelId) else Notification.Builder(this)
        val n = builder.setContentTitle("LagLab is running")
            .setContentText("Tap the floating button to start the lag")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun addButton() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val size = px(Prefs.sizeDp(this))
        @Suppress("DEPRECATION")
        val phoneType = WindowManager.LayoutParams.TYPE_PHONE
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else phoneType
        lp = WindowManager.LayoutParams(
            size, size, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = px(16)
            y = px(220)
        }

        val slop = ViewConfiguration.get(this).scaledTouchSlop
        val tv = TextView(this)
        tv.gravity = Gravity.CENTER
        tv.setTextColor(Color.parseColor("#08110D"))
        tv.typeface = Typeface.DEFAULT_BOLD
        tv.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX
                    downY = e.rawY
                    startX = lp.x
                    startY = lp.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (moved) {
                        lp.x = startX + dx.toInt()
                        lp.y = startY + dy.toInt()
                        wm.updateViewLayout(v, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onTap()
                    true
                }
                else -> false
            }
        }
        view = tv
        wm.addView(tv, lp)
        render()
    }

    private fun onTap() {
        if (LagState.active) stopLag() else startLag()
    }

    private fun startLag() {
        remaining = Prefs.seconds(this)
        LagState.active = true
        render()
        handler.removeCallbacks(tick)
        handler.postDelayed(tick, 1000)
    }

    private fun stopLag() {
        handler.removeCallbacks(tick)
        LagState.active = false
        render()
    }

    private fun render() {
        val tv = view ?: return
        val active = LagState.active
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(Color.parseColor(if (active) "#FF7A45" else "#2EE6A6"))
        tv.background = bg
        tv.text = if (active) "$remaining" else "${Prefs.seconds(this)}s"
        tv.setTextSize(TypedValue.COMPLEX_UNIT_PX, lp.width * 0.36f)
    }

    /** Called from MainActivity when the size or seconds change. */
    fun applySettings() {
        val size = px(Prefs.sizeDp(this))
        lp.width = size
        lp.height = size
        val tv = view
        if (tv != null) {
            try {
                wm.updateViewLayout(tv, lp)
            } catch (e: Exception) {
            }
        }
        render()
    }

    override fun onDestroy() {
        stopLag()
        view?.let {
            try {
                wm.removeView(it)
            } catch (e: Exception) {
            }
        }
        view = null
        instance = null
        super.onDestroy()
    }
}
