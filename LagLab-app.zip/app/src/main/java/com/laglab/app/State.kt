package com.laglab.app

import android.content.Context

object LagState {
    /** Delay added to every packet, in each direction, while lag is ON (the fixed "Medium" level). */
    const val LAG_MS = 300L

    @Volatile var active = false
    @Volatile var running = false
}

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("laglab", Context.MODE_PRIVATE)

    fun seconds(c: Context): Int = sp(c).getInt("sec", 3)
    fun setSeconds(c: Context, v: Int) = sp(c).edit().putInt("sec", v).apply()

    fun sizeDp(c: Context): Int = sp(c).getInt("size", 40)
    fun setSizeDp(c: Context, v: Int) = sp(c).edit().putInt("size", v).apply()

    fun target(c: Context): String = sp(c).getString("target", "") ?: ""
    fun targetLabel(c: Context): String = sp(c).getString("targetLabel", "All apps") ?: "All apps"
    fun setTarget(c: Context, pkg: String, label: String) =
        sp(c).edit().putString("target", pkg).putString("targetLabel", label).apply()
}
