package com.laglab.app

import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor

class LagVpnService : VpnService() {

    private var pfd: ParcelFileDescriptor? = null
    private var engine: PacketEngine? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (engine == null) startVpn()
        return START_NOT_STICKY
    }

    private fun startVpn() {
        val b = Builder()
            .setSession("LagLab")
            .setMtu(1500)
            .setBlocking(true)
            .addAddress("10.8.0.2", 32)
            .addRoute("0.0.0.0", 0)
            .addDnsServer("8.8.8.8")
            .addDnsServer("1.1.1.1")

        val target = Prefs.target(this)
        var restricted = false
        if (target.isNotEmpty()) {
            try {
                b.addAllowedApplication(target)
                restricted = true
            } catch (e: Exception) {
            }
        }
        if (!restricted) {
            try {
                b.addDisallowedApplication(packageName)
            } catch (e: Exception) {
            }
        }

        val fd = b.establish()
        if (fd == null) {
            stopSelf()
            return
        }
        pfd = fd
        engine = PacketEngine(this, fd).also { it.start() }
        LagState.running = true
    }

    private fun stopVpn() {
        engine?.stop()
        engine = null
        try {
            pfd?.close()
        } catch (e: Exception) {
        }
        pfd = null
        LagState.running = false
        LagState.active = false
    }

    override fun onRevoke() {
        stopVpn()
        stopService(Intent(this, FloatingService::class.java))
        super.onRevoke()
    }

    override fun onDestroy() {
        stopVpn()
        super.onDestroy()
    }
}
